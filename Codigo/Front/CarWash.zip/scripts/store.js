let description = 'Hello Hero';

module.exports = {
  description
}